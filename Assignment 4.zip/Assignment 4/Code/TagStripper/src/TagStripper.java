import java.util.Scanner;
import java.io.*;

public class TagStripper {
	public static void main(String[] args)throws IOException{
		Scanner scan = new Scanner(new File("docs/TestSetTagged.txt"));
		String text = "";
		
		while(scan.hasNextLine()){
			text += scan.nextLine() + "\n";
		}
		scan.close();
		
		text = text.replace("_pron ", " ");
		text = text.replace("_pres ", " ");
		text = text.replace("_adv ", " ");
		text = text.replace("_loc ", " ");
		text = text.replace("_dem ", " ");
		text = text.replace("_cop ", " ");
		text = text.replace("_conj ", " ");
		text = text.replace("_intj ", " ");
		text = text.replace("_pos ", " ");
		text = text.replace("_rel ", " ");
		text = text.replace("_p ", " ");
		text = text.replace("_n ", " ");
		text = text.replace("_m ", " ");
		text = text.replace("_v ", " ");
		text = text.replace("_a ", " ");
		
		
		text = text.replace("_pron\n", "\n");
		text = text.replace("_pres\n", "\n");
		text = text.replace("_adv\n", "\n");
		text = text.replace("_loc\n", "\n");
		text = text.replace("_dem\n", "\n");
		text = text.replace("_cop\n", "\n");
		text = text.replace("_conj\n", "\n");
		text = text.replace("_intj\n", "\n");
		text = text.replace("_pos\n", "\n");
		text = text.replace("_rel\n", "\n");
		text = text.replace("_p\n", "\n");
		text = text.replace("_n\n", "\n");
		text = text.replace("_m\n", "\n");
		text = text.replace("_v\n", "\n");
		text = text.replace("_a\n", "\n");
		
		FileWriter newfileWrite = new FileWriter(new File("docs/TestSetUntagged.txt"));
		PrintWriter newPrintWrite = new PrintWriter(newfileWrite);
		newPrintWrite.print(text);
		newPrintWrite.close();
		System.out.println(text);
	}
}
