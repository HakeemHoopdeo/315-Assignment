

import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import java.util.Scanner;
import java.io.*;

public class ZuluTagger {

	public static void main(String[] args) throws IOException{

		Scanner scan = new Scanner(new File("models/TestSetUntagged.txt"));
		String text = "";
		String TaggedSet = "";
		FileWriter fileWrite  = new FileWriter(new File("models/MachineTaggedText.txt"));
		PrintWriter printWrite = new PrintWriter(fileWrite);
		
		MaxentTagger tagger = new MaxentTagger("models/zulu-pos-tagger-model.tagger");
		
		
		while(scan.hasNextLine()){
			text = scan.nextLine();
			TaggedSet += tagger.tagString(text) + "\n";
		}
		printWrite.print(TaggedSet);
		printWrite.close();
		scan.close();
		System.out.println(TaggedSet);
		
	}
}
