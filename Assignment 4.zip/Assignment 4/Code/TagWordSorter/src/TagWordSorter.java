

import java.util.Arrays;
import java.io.*;
import java.util.Scanner;


public class TagWordSorter {
	public static void main(String[] args)throws IOException{
		
		String[] POSTAGArray = new String[]{"_pron","_pres","_adv","_loc","_dem","_cop","_conj","_intj","_pos","_rel","_p","_n","_m","_v","_a"};
		int[] POSTAGCount = new int[15];
			
		String text = "";
		String textMT = "";
		
		Scanner testScanner = new Scanner(new File("docs/TestSetTagged.txt"));

		Scanner taggedScanner = new Scanner(new File("docs/MachineTaggedText.txt"));
		
		while(testScanner.hasNext()){
			text += testScanner.next() + " ";
		}
		testScanner.close();
		
		while(taggedScanner.hasNext()){
			textMT += taggedScanner.next()+" ";
		}
		taggedScanner.close();
		
		String[] tagArray;
		String[] MTagArray;
		
		tagArray = text.split(" ");
		MTagArray = textMT.split(" ");
		
		int index = 0;
		String temp = "";
		for(int i = 0; i < tagArray.length; i++){
			temp = tagArray[i].substring(tagArray[i].indexOf("_"), tagArray[i].length());
			index = Arrays.asList(POSTAGArray).indexOf(temp);
			POSTAGCount[index]++;
			index = 0;
		}
		int sum = 0;
		System.out.println("Total Number of Tags: ");
		for(int i = 0; i < POSTAGArray.length; i++){
			System.out.println(POSTAGArray[i]+"\t--> "+POSTAGCount[i]);
			sum += POSTAGCount[i];
		}
		System.out.println("\nTotal number of tags\t--> "+sum+"\n\n");
		
		
		System.out.println("The Confusion Matrix:");
		
		
		if(tagArray.length != MTagArray.length){
			System.out.println("The texts could not be compared. One of the texts is missing data");
			return;
		}else{
			String taggedTextTag = "";
			String MTaggedTextTag = "";
			int[][] confusionMatrix = new int[POSTAGArray.length][POSTAGArray.length];
			int CMRow = 0;
			int CMCol = 0;
			for(int i = 0; i < tagArray.length; i++){
				
				taggedTextTag =  tagArray[i].substring(tagArray[i].indexOf("_"), tagArray[i].length());
				MTaggedTextTag = MTagArray[i].substring(MTagArray[i].indexOf("_"),MTagArray[i].length());
				CMRow = Arrays.asList(POSTAGArray).indexOf(taggedTextTag);
				CMCol = Arrays.asList(POSTAGArray).indexOf(MTaggedTextTag);
				confusionMatrix[CMRow][CMCol]++;
				CMRow = 0;
				CMCol = 0;
			}
			//Printing the confusion matrix to the console
			System.out.print("\t");
			for(int i = 0; i < POSTAGCount.length; i++){
				System.out.print("\t"+POSTAGArray[i]);
			}
			System.out.println();
			for(int row = 0; row < confusionMatrix.length; row++){
				System.out.print(POSTAGArray[row]+"\t\t");
				for(int col = 0; col < confusionMatrix[row].length; col++){
					System.out.print(confusionMatrix[row][col]+"\t");
				}
				System.out.println();
			}

		}
		
	}

}