﻿#include "MainGame.h"

MainGame mainGame;

void MainGame::numPlayersPrompt() {
	cout << "\nEnter number of players: ";
	cin >> numPlayer;
	while (!valid.isValidInt(numPlayer) || !valid.inCategoryRange(numPlayer, 0)) {
		cout << "Invalid number.\nPlease enter a number between 1 and 4: ";
		cin >> numPlayer;
	}
	difficultyLevelPrompt();
}

void MainGame::difficultyLevelPrompt() {
	system("cls");
	cout << "Easy = 0\nChallenging = 1\nGod Mode = 2\nEnter the difficulty Level or x to change the number of players you want: ";
	cin >> difficultyLevel;
	if (rollback(difficultyLevel))
		numPlayersPrompt();
	else {
		while (!valid.isValidInt(difficultyLevel) || !valid.inCategoryRange(difficultyLevel, 1)) {
			cout << "Invalid difficulty level!!!\nPlease enter a difficulty level between 0 and 2: ";
			cin >> difficultyLevel;
		}
		ExpMaker.setDifficultyLevel(stoi(difficultyLevel));
		numQuestionsPrompt();
	}
	system("cls");
}

void MainGame::numQuestionsPrompt() {
	system("cls");
	cout << "Enter the number of questions between 5 and 10 or x to change the difficulty level you want: ";
	cin >> numQuestions;
	if (rollback(numQuestions))
		difficultyLevelPrompt();
	else {
		while (!valid.isValidInt(numQuestions) || !valid.inCategoryRange(numQuestions, 2)) {
			cout << "Invalid number of questions!!! \nPlease enter the number of questions between 5 and 10: ";
			cin >> numQuestions;
		}
	}
	system("cls");
}

void MainGame::usernamePrompt() {
	system("cls");
	cout << "Enter your username or x to change how many questions you want: ";
	cin >> user;
	if (rollback(user))
		numQuestionsPrompt();
	else {
		while (!valid.inCategoryRange(user, 3) || !valid.isUniqueUsername(user)) {
			cout << "Invalid username!!!\nPlease enter a new username between 3 and 20 letters: ";
			cin >> user;
		}
		confirmReadyPrompt();
	}
	system("cls");
}

void MainGame::confirmReadyPrompt() {
	system("cls");
	string confirmation;
	cout << "Enter any other key to continue or x to change your username: ";
	cin >> confirmation;
	if (rollback(confirmation))
		usernamePrompt();
	system("cls");
}

bool MainGame::playAgainPrompt() {
	string playAgain;
	cout << "Enter x to end the game or Enter any other key to finish your review and play again:";
	cin >> playAgain;
	if (valid.validatePlayAgain(playAgain) && playAgain != "A" && playAgain != "B" && playAgain != "C")
		return true;
	return false;
}

int MainGame::generateIncorrectAnswer() {
	incorrectAnswer = correctAnswer;
	while (incorrectAnswer == correctAnswer)
		incorrectAnswer = (correctAnswer - 10) + (rand() % ((correctAnswer + 10) - (correctAnswer - 10) + 1));
	return incorrectAnswer;
}

void MainGame::playerPrompt(int i) {
	auto start = high_resolution_clock::now();
	string rev = "";
	cout << "P" << mainGame.currentPlayer.playerNo << " - " << mainGame.currentPlayer.username << "\'s turn:\n";
	ExpMaker.generateExpression();
	string Question = ExpMaker.getExpression();
	correctAnswer = ExpMaker.getFinalResult();

	incorrectAnswer = generateIncorrectAnswer();
	if (generateRandomlyChosenAnswer() == 1) {
		answerTypeToAsk = correctAnswer;
	}
	else {
		answerTypeToAsk = incorrectAnswer;
	}
	questionTypeToAsk = generateQuestionType();  // Generates T or F 
	askQuestion(i);
	rev += "The expresssion is : " + Question + "\nIs the result " + to_string(answerTypeToAsk)
		+ " " + questionTypeToAsk + "?";
	if (valid.needHelp) {
		cout << ExpMaker.getSolution();
		cout << "\nEnter any key to continue the quiz!!!";
		string cont = "";
		cin >> cont;
		rev += "\nYou did not answer!!! \nHere's how it's done:\n" + ExpMaker.getSolution();
	}
	else {
		string ans = "F";
		if (to_string(toupper(playerAnswer[0])) == "84")
			ans = "T";
		rev += "\nYour Answer was " + ans;
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<seconds>(stop - start);
		saveAnswer(i);
		if (isCorrect()) {
			//PlaySound(TEXT("correct.wav"), NULL, SND_SYNC);
			currentPlayer.numQuestionsCorrectlyAnswered++;  //increments so we know the total number of incorrect questions
			int value = 10;
			if (duration.count() >= ExpMaker.getTimeLimit()) {
				rev += "\nCORRECT ANSWER... BUT TIME LIMIT EXCEEDED!!! :( ";
			}
			else {
				value += static_cast<int>(std::round((((float)ExpMaker.getTimeLimit() -
					(float)duration.count()) / (float)ExpMaker.getTimeLimit()) * 90));
				rev += " which is " + tofVar + " because the result of the expression is: " + to_string(correctAnswer) + "\n";
			}
			static_cast<int>(std::round(value));
			currentPlayer.totalScore += value; //Total score
			currentPlayer.totalTime += static_cast<int>(std::round(duration.count())); //Total time taken

			rev += "Your Score for this Question was: [" + to_string(value) + "/100]\n";
		}
		else {
			//PlaySound(TEXT("fail.wav"), NULL, SND_SYNC);
			//bad sound
			rev += " which is " + tofVar + " because the result of the expression is: " + to_string(correctAnswer);
			rev += "\nYour Score for this Question was: [0/100]";
			rev += "\nHere's how it's done:\n" + ExpMaker.getSolution();
		}
		rev += "Time taken was: " + to_string(duration.count()) + " seconds\n";
	}

	rev += "The correct answer was: " + tofVar;
	currentPlayer.Review[i] = { rev };
}

void MainGame::displayReview() {
	cout << "\nSummary of P" << currentPlayer.playerNo << " - " << currentPlayer.username << "'s performance: ";
	for (int i = 1; i <= stoi(numQuestions); i++) {
		cout << "\nQuestion " << i << ": " << currentPlayer.Review[i] << "\n";
		Sleep(1000);//sleep for 10 seconds before displaying next reiew
	}
	cout << "\nFor P" << currentPlayer.playerNo << " - " << currentPlayer.username << ": ";
	if (currentPlayer.numQuestionsCorrectlyAnswered != 0) {
		cout << "\nThe total number of questions correctly answered is:"
			<< currentPlayer.numQuestionsCorrectlyAnswered << endl;
		cout << "\nThe total time taken to answer the questions is:"
			<< currentPlayer.totalTime << " seconds!" << endl;
	}
	else
		cout << "YOU'VE ANSWERED ALL WRONG!!! MUSHY DIED!!!";
	Sleep(2000);
}

void MainGame::saveAnswer(int i) {
	if ((playerAnswer == "T" || playerAnswer == "t") && !isCorrect())
		tofVar = "false";
	else if ((playerAnswer == "F" || playerAnswer == "f") && !isCorrect())
		tofVar = "true";
	else if ((playerAnswer == "T" || playerAnswer == "t") && isCorrect())
		tofVar = "true";
	else if ((playerAnswer == "F" || playerAnswer == "f") && isCorrect())
		tofVar = "false";
}

void MainGame::askQuestion(int i) {
	cout << "Question " << i << " of " << numQuestions << ": ";
	questionAccumulator(i);
	cout << "Is the result " << answerTypeToAsk << " " << questionTypeToAsk << "?" << endl;
	cin >> playerAnswer;
	while (!valid.isPlayerAnsValid(playerAnswer)) {
		cout << "Invalid format!\nPlease enter a \"T\" or \"F\" or \"HELP\": ";
		cin >> playerAnswer;
	}
}

void MainGame::questionAccumulator(int i) {
	cout << "|";
	for (int j = 1; j <= i; j++) {
		if (j == i) 
			cout << mainGame.avatars[randomPositionAvatar] <<" |";
		else if ((j == i - 1) && (ExpMaker.getDifficultyLevel() == 2))
			cout << " /\\/\\(0 .. 0)/\\/\\ |";
		else if ((j == i - 1) && (ExpMaker.getDifficultyLevel() == 1))
			cout << " (\\/)!_!(\\/) |";
		else if ((j == i - 1) && (ExpMaker.getDifficultyLevel() == 0))
			cout << " (`(oo)`) |";
		else
			cout <<"      |" ;
	}
	int incompletePortion = stoi(numQuestions) - i;
	for (int j = 1; j <= incompletePortion; j++) 
		cout << "     |";
	if (i == stoi(numQuestions))
		cout << "\nALMOST COMPLETE!!! KEEP GOING!!!\n";
	else
		cout << "	"<< mainGame.avatarNames[randomPositionAvatar] << " ZONE\n";
}

bool MainGame::isCorrect() {  //Maybe use a truth table to double check
	if ((answerTypeToAsk == correctAnswer && questionTypeToAsk == "correct" && (playerAnswer == "T" || playerAnswer == "t")) ||
		(answerTypeToAsk == correctAnswer && questionTypeToAsk == "incorrect" && (playerAnswer == "F" || playerAnswer == "f")) ||
		(answerTypeToAsk == incorrectAnswer && questionTypeToAsk == "correct" && (playerAnswer == "F" || playerAnswer == "f")) ||
		(answerTypeToAsk == incorrectAnswer && questionTypeToAsk == "incorrect" && (playerAnswer == "T" || playerAnswer == "t")))
		return true;
	return false;
}

void MainGame::displayStats() {
	string pronoun = "";
	if (stoi(mainGame.numPlayer) == 1)
		pronoun = "Your";
	else
		pronoun = mainGame.currentPlayer.username + "\'s";
	cout << "GENERATING RESULTS for P" << mainGame.currentPlayer.playerNo << " - " << mainGame.currentPlayer.username;
	Sleep(2000);// sleeps for 2 seconds 
	if (stoi(mainGame.numPlayer) == 1)
		pronoun = "YOU";
	else
		pronoun = mainGame.currentPlayer.username;
	cout << "\nDID " << pronoun << " SAVE " << mainGame.avatarNames[randomPositionAvatar] << "???\n";
	Sleep(4000);
	if (mainGame.currentPlayer.totalScore < (stoi(mainGame.numQuestions) * 50)) {
		//PlaySound(TEXT("incorrect.wav"), NULL, SND_ASYNC);
		cout << pronoun << " FAILED TO SAVE " << mainGame.avatarNames[randomPositionAvatar] << "!!! x_x \n" << endl;
	}
	else {
		//PlaySound(TEXT("sucess.wav"), NULL, SND_ASYNC);
		cout << pronoun << " SAVED " << mainGame.avatarNames[randomPositionAvatar] << "!!!" << mainGame.avatars[randomPositionAvatar] << "\n" << endl;
	}
	if (stoi(numPlayer) == 1)
		pronoun = "Your";
	else
		pronoun += "\'s";
	Sleep(2500);
	cout << pronoun << " Score was: ";
	Sleep(2000);
	cout << mainGame.currentPlayer.totalScore << endl;
	Sleep(2000);
	cout << pronoun << " Grade was: ";
	Sleep(2000);  //sleep for 2 seconds before displaying grade
	cout << mainGame.getGrade(mainGame.currentPlayer.totalScore) << endl;
	Sleep(2000);
	mainGame.displayReview();
}

MainGame::MainGame() { }

MainGame::~MainGame() { }

void MainGame::populateVectors() {
	vecPlayers.push_back(currentPlayer);
	vecUsername.push_back(currentPlayer.username);
	vecTotalScore.push_back(currentPlayer.totalScore);
	vecTotalTime.push_back(currentPlayer.totalTime);
	vecNumQuestionsCorrectlyAnswered.push_back(currentPlayer.numQuestionsCorrectlyAnswered);
}

void MainGame::filterScore() {
	vector<Player> vecCopyPlayer = mainGame.vecPlayers;
	GenericSorting<int, Player> gsTotalScore(&mainGame.vecTotalScore, &vecCopyPlayer);
	gsTotalScore.sort(mainGame.vecTotalScore.size());
	cout << "The Player details filtered by Score: " << endl;
	for (int i = 0; i < mainGame.vecTotalScore.size();i++ )
		
		cout << "P" << vecCopyPlayer.at(i).playerNo << " - " << vecCopyPlayer[i].username << ": " << vecTotalScore[i] << endl;
	/*for(auto const& v: vecTotalScore)
		cout << "P" << vecCopyPlayer[i].playerNo << " - " << vecCopyPlayer[i].username << ": " << v[i] << endl;*/
}
void MainGame::filterTime() {
	vector<Player> vecCopyPlayer = mainGame.vecPlayers;
	GenericSorting<int, Player> gsTotalTime(&mainGame.vecTotalTime, &vecCopyPlayer);
	gsTotalTime.sort(mainGame.vecTotalTime.size());
	cout << "The Player details filtered by Time: " << endl;
	for (int i = 0; i < mainGame.vecTotalTime.size(); i++)
		cout << "P" << vecCopyPlayer[i].playerNo << " - " << vecCopyPlayer[i].username << ": " << vecTotalTime[i] << endl;

}
void MainGame::filterCorrectQuestions() {
	vector<Player> vecCopyPlayer = mainGame.vecPlayers;
	GenericSorting<int, Player> gsTotalCorrectAnswers(&mainGame.vecNumQuestionsCorrectlyAnswered, &vecCopyPlayer);
	gsTotalCorrectAnswers.sort(mainGame.vecNumQuestionsCorrectlyAnswered.size());
	cout << "The Player details filtered by Most Questions Answered correctly: " << endl;
	for (int i = 0; i < mainGame.vecNumQuestionsCorrectlyAnswered.size(); i++)
		cout << "P" << vecCopyPlayer[i].playerNo << " - " << vecCopyPlayer[i].username << ": " << vecNumQuestionsCorrectlyAnswered[i] << endl;
}

void MainGame::filters() {

	while (true) {
		if (stoi(mainGame.numPlayer) == 1) {
			cout << "ENTER X TO END GAME OR PRESS ANY KEY TO PLAY AGAIN\n";
		}
		else
			cout << "A - FILTER PLAYERS BY SCORE\n" << "B - FILTER PLAYERS BY FASTEST TIME\n" << "C - FILTER PLAYERS BY MOST QUESTIONS CORRECTLY ANSWERED\n"
			<< "X - EXIT THE GAME\n" << "ENTER ANY OTHER CHARACTER - PLAY AGAIN\n";
		char input;
		cin >> input;
		input = (char)toupper(input);
		bool needMe = true;
		if (/*!valid.validatePlayAgain(input)*/ input == 'X') {
			system("cls");
			cout << "THANK YOU FOR PLAYING OUR GAME!!!";
			mainGame.displayCredits();
			needMe = false;
			break;
			//displayVredit() and break;
		}
		else if (stoi(numPlayer) != 1) {
			if (input == 'A') {
				filterScore();
				needMe = false;
			}
			//if B gilterAnother()
			else if (input == 'B') {
				filterTime();
				needMe = false;
			}
			//if C go;etrrAnother()
			else if (input == 'C') {
				filterCorrectQuestions();
				needMe = false;
			}
			/*else {
				system("cls");
				mainGame.playerQueue = queue<Player>();
				mainGame.vecUsername = vector<string>();
				mainGame.vecTotalScore = vector<int>();
				mainGame.vecTotalTime = vector<int>();
				mainGame.vecPlayers = vector<Player>();
				mainGame.vecNumQuestionsCorrectlyAnswered = vector<int>();
				playAgain = true;
				break;
			}

			fine you wana know?
			i got swearing again
			this is normal for me
			not really i just dont know
		}
		else if (stoi(numPlayer) > 0) {//playAgaunwith main()
			system("cls");
			mainGame.playerQueue = queue<Player>();
			mainGame.vecUsername = vector<string>();
			mainGame.vecTotalScore = vector<int>();
			mainGame.vecTotalTime = vector<int>();
			mainGame.vecPlayers = vector<Player>();
			mainGame.vecNumQuestionsCorrectlyAnswered = vector<int>();
			playAgain = true;
			break;
		}*/
		}
			if (needMe) {
				system("cls");
				mainGame.playerQueue = queue<Player>();
				mainGame.vecUsername = vector<string>();
				mainGame.vecTotalScore = vector<int>();
				mainGame.vecTotalTime = vector<int>();
				mainGame.vecPlayers = vector<Player>();
				mainGame.vecNumQuestionsCorrectlyAnswered = vector<int>();
				playAgain = true;
				break;
			}
		

	}

	/*switch (input) {
	case 'A':
		filterScore();
		filters();
		break;
		
	case 'B' : 
		filterTime();
		filters();
		break;
	case 'C' :
		filterCorrectQuestions();
		filters();
		break;
	case 'X':
		//end Game
		system("cls");
		cout << "THANK YOU FOR PLAYING OUR GAME!!!";
		mainGame.displayCredits();
		break;
	default: 
		//play again
		system("cls");
		mainGame.playerQueue = queue<Player>();
		mainGame.vecUsername = vector<string>();
		mainGame.vecTotalScore = vector<int>();
		mainGame.vecTotalTime = vector<int>();
		mainGame.vecNumQuestionsCorrectlyAnswered = vector<int>();
		//mainGame.main();
		mainGame.playAgain = true;
		break;
	}*/

}
//breaks endgame
//play again

/*void MainGame::sortVectors() {
needs to become mpv function
	vector<Player> vecCopyPlayer = vecPlayers;
	GenericSorting<int, Player> gsTotalScore(&vecTotalScore, &vecPlayers);
	gsTotalScore.sort(vecTotalScore.size());
	cout << "\nThe highest score was: " << vecTotalScore.at(vecTotalScore.size() - 1) << " By P" << vecPlayers.at(vecUsername.size() - 1).playerNo <<" - " << vecPlayers.at(vecUsername.size() - 1).username;

	vecPlayers = vecCopyPlayer;
	GenericSorting<int, Player> gsTotalTime(&vecTotalTime, &vecPlayers);
	gsTotalTime.sort(vecTotalTime.size());
	cout << "\nThe fastest time was: " << vecTotalTime.at(0) << " By P" << vecPlayers.at(0).playerNo << " - " << vecPlayers.at(0).username;

	vecPlayers = vecCopyPlayer;
	GenericSorting<int, Player> gsNumQuestionsCorrectlyAnswered(&vecNumQuestionsCorrectlyAnswered, &vecPlayers);
	gsNumQuestionsCorrectlyAnswered.sort(vecNumQuestionsCorrectlyAnswered.size());
	cout << "\nThe highest amount of correctly answered questions is: "
		<< vecNumQuestionsCorrectlyAnswered.at(vecNumQuestionsCorrectlyAnswered.size() - 1) 
		<< " By P" << vecPlayers.at(vecUsername.size() - 1).playerNo << " - " << vecPlayers.at(vecUsername.size() - 1).username << endl;
}*/

void MainGame::createTeams() {
	Team alpha;
	alpha.teamName = "Team Alpha:";
	alpha.combinedPlayerStats = (vecPlayers.at(0) + vecPlayers.at(1));
	
	Team omega;
	omega.teamName = "Team Omega:";
	omega.combinedPlayerStats = (vecPlayers.at(2) + vecPlayers.at(3));
	displayTeams(alpha, omega);
}

void MainGame::displayTeams(Team alpha, Team omega) {
	cout << "\n" << alpha.teamName << endl;
	cout << "Combined Score is: " << alpha.combinedPlayerStats.totalScore;
	cout << "\nCombined Time is: " << alpha.combinedPlayerStats.totalTime;
	cout << "\nCombined correct questions is: " << alpha.combinedPlayerStats.numQuestionsCorrectlyAnswered;

	cout << "\n" << alpha.teamName << endl;
	cout << "Combined Score is: " << omega.combinedPlayerStats.totalScore;
	cout << "\nCombined Time is: " << omega.combinedPlayerStats.totalTime;
	cout << "\nCombined correct questions is: " << omega.combinedPlayerStats.numQuestionsCorrectlyAnswered << endl;
}

int main() {
	mainGame.playAgain = false;
	srand((unsigned)time(0));
	mainGame.randomPositionAvatar = rand() % 4;
	cout << "Good evening!!!\nGet "<< mainGame.avatarNames[mainGame.randomPositionAvatar] 
		 << mainGame.avatars[mainGame.randomPositionAvatar] <<" to safety from the fiery arrows";
	mainGame.numPlayersPrompt();
	cout << "GAME STARTING...";
	for (int i = 1; i <= stoi(mainGame.numPlayer); i++) {
		mainGame.usernamePrompt();
		mainGame.playerQueue.push(mainGame.createPlayers(i));
	}
	int qNum = 0;
	for (int i = 1; i <= stoi(mainGame.numQuestions); i++) {
		qNum = i;
		for (int j = 1; j <= stoi(mainGame.numPlayer); j++) {
			mainGame.currentPlayer = mainGame.playerQueue.front();
			mainGame.playerQueue.pop();

			cout << "Generating Question...";
			mainGame.sleepBasedOnDifficultyLevel();
			system("cls");
			mainGame.playerPrompt(qNum);

			mainGame.playerQueue.push(mainGame.currentPlayer);
		}
	}
	std::system("cls");
	cout << "QUIZ COMPLETE!!! WELL DONE!!!\n";
	for (int i = 1; i <= stoi(mainGame.numPlayer); i++) {
		mainGame.currentPlayer = mainGame.playerQueue.front();
		mainGame.playerQueue.pop();
		mainGame.populateVectors();
		/*mainGame.displayStats();*/
		
		mainGame.playerQueue.push(mainGame.currentPlayer);
	}
	cout << mainGame.vecPlayers.size() << endl;
	cout << mainGame.vecTotalScore.size() << endl;
	/*cout << mainGame.vecTotalScore.size() << endl;
	cout << mainGame.vecn.size() << endl;*/
	/*if (stoi(mainGame.numPlayer) > 1)
		mainGame.sortVectors();
	*/

	if (stoi(mainGame.numPlayer) == 4) 
		mainGame.createTeams();

	/*if (stoi(mainGame.numPlayer) > 1) {
		
	}
	else {
		if (mainGame.playAgainPrompt()) {
			system("cls");
			mainGame.playerQueue = queue<Player>();
			mainGame.vecUsername = vector<string>();
			mainGame.vecTotalScore = vector<int>();
			mainGame.vecTotalTime = vector<int>();
			mainGame.vecNumQuestionsCorrectlyAnswered = vector<int>();
			main();
		}
		else {
			system("cls");
			cout << "THANK YOU FOR PLAYING OUR GAME!!!";
			mainGame.displayCredits();
		}
	}*/

	mainGame.filters();
	if (mainGame.playAgain)
		main();
}

Player operator+(Player const& p1, Player const& p2) {	
	Player p;
	p.totalScore = p1.totalScore + p2.totalScore;
	p.totalTime = p1.totalTime + p2.totalTime;
	p.numQuestionsCorrectlyAnswered = p1.numQuestionsCorrectlyAnswered + p2.numQuestionsCorrectlyAnswered;
	return p;
}