#pragma once
#include <iostream>
#include <cstring>
#include <string>

using namespace std;

class Validation {
public:
	bool needHelp = false;
	Validation();
	~Validation();
	bool isValidInt(string input);
	bool isPlayerAnsValid(string input);
	bool isAskingForHelp(string num);
	bool isUniqueUsername(string num/*pass reference to map -- map myMap, newUsername*/);
	/* if newUsername[i] == myMap[i].username*/
	/* use our userdefined method*/
	bool inCategoryRange(string num, int category);
};