#pragma once
#include <string>
#include <vector>
//#include <stack>
#include <ctime>
#include <cstdlib>
#include <iostream>

using namespace std;

/* 

WHEN FINISHED GO THROUGH EVERY LINE OF CODE
TO MAKE SURE THERE'S NOTHING UNNECCARY / LEWD

*/

/*
Note:   - difficulty level of 0: Easy will generate numbers from 1-9 with 2 operators
		- difficulty level of 1: Medium will generate numbers from 10-20 with 4 operators
		- difficulty level of 2: Hard will generate numbers from 20-50 with 6 operators
		- If currentOperator is Divison, we must calculate all divisors for the
		  currentRandom number and pick a random divisor of a vector of divisors
		- we still need to generate multiple random numbers
		- This class generates multiple random expressions
		- Some expressions can result in a negative answer
		  depending on the situation but it's fairly rare*/
		  //queue<map<int, Player>> 

class HakExpressionMaker {
private:
	int randOp = 0;  //random num will determine which operator we will use from opChoice.

	int difficultyLevel;  //will be used to determine the range of randNum (maybe use enum or restrict 1-4 later on).

	int randNum{ 0 };  //the newly generated randNum within appropriate range.

	int finalResult{ 0 };  //stores the final result of the expression using calculateFinalResult.

	int upBound{ 0 };  //initialised based on difficultyLevel.

	int lowBound{ 0 };  //initialised based on difficultyLevel.

	int expLength{ 0 };  //stores the length of the expression based on difficultyLevel.

	int archive{ 0 };  //used with division to store the result of divison.

	int timeLimit{ 0 };  //used to limit the time per question to a specified constant based on difficultyLevel.

	bool isPrevOpDiv = false;  //used in tandem with archive to ensure that consecutive division strictly produces integers.
	
	bool isPrevOpMult = false;  //will be used to ensure division isn't consecutive to reduce BODMAS issues and time.
	
	string expression{ 0 };  //used for easy output of our expression.
	
	string workingString{ 0 };  //store the working out for the expression - to be dislayed for help / wrong answer.
	
	const string opChoice[4] = { "-", "+", "*", "/" };  //stores the operators that we are working with.
	
	vector<int> divisors{ 0 };  //used to store all the divisors of the prev randNum(now archive) if / is the next randOp.
	
	vector<string> mathExp;  //used to store our expression and calculate the working out.
	
	//vector<string> allSolutions;  //stores the working out of each expression

	/* DELETE INLINE IF ERRORS */

	/*Initializes the range according to the difficulty level, please note, the only time you will see
	 numbers that are in other ranges , it's because of finding all the divisors and picking a random
	 divisor that will enable us to get an integer result*/
	void genRange();
	
	/*Generates(set method) a random operator for the equation,
	 ensures that the multiplication operator isn't consecutive, and
	 ensures that if the previous number is prime, there will be no division
	 for that prime number.*/
	void genRandOp();

	/*This function generates a vector of divisors of the previous randNum should the new randOp
	 be division. Used in tandem with genRandNumForDiv() to choose a random element from the vector
	 divisors to force the result to be an integer*/
	void genDivisors();

	/*This function will call the generateDivisors() method which initialises a vector of divisors called divisors
	 then select a random element from that vector to be the divisor before destroying the vector*/
	int genRandNumForDiv();
public:
	HakExpressionMaker();
	~HakExpressionMaker();

	/*Constructor to set difficulty level.*/
	HakExpressionMaker(int difficulty);

	/*FUNCTION USING VECTORS TO EVALUATE THE EXPRESSION.*/
	int calculateFinalResult(vector<string>& expVector);

	/*Generates the valid expression.*/
	void generateExpression();

	int getDifficultyLevel();
	
	/*call in constructor or where necessary.*/
	void setDifficultyLevel(int difficultyLevel);
	
	int getTimeLimit();
	
	int getFinalResult();
	
	string getExpression();
	
	void workingOut(vector<string>& v);
	
	string getSolution();
	
	void setSolution(int i);

inline int doOperation(int Operater, int& num1, int& num2) {
	switch (Operater) {
	case 0:
		return num1 - num2;
	case 1:
		return num1 + num2;
	case 2:
		return num1 * num2;
	case 3:
		return num1 / num2;
	default:
		cout << "DO Nothing";
		return 1;
	}
}

inline void resetAttributes() {
	randOp = 0;
	randNum = 0;
	expression = "";
	workingString = "";
}

/*Generates a random number for addition, subtraction and multiplication*/
inline int genRandNum() {
	if (randOp == 2)
		randNum = 1 + (rand() % (5 - 1 + 1));
	else
		randNum = lowBound + (rand() % (upBound - lowBound + 1));
	return randNum;
}

};