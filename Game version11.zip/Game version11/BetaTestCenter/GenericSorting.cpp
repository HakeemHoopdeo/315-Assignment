#include "GenericSorting.h"

/*template<typename T> int GenericSorting<T>::compareTo(T val1, T val2) {
	if (val1 < val2)
		return -1;
	else if (val1 > val2)
		return 1;
	return 0;
}*/

int main() {
	vector<int> vectorI = {7, 5, -75, 32, -6};
	vector<double> vectorD = {7.5, 2, -6, 5.64, 1.45};
	vector<string> vectorS = {"Hello", "Nikiel", "Hakeem", "Goku", "Hakai"};
	GenericSorting<int> gsInt(&vectorI);
	gsInt.sort(5);
	GenericSorting<double> gsDouble(&vectorD);
	gsDouble.sort(5);
	GenericSorting<string> gsString(&vectorS);
	gsString.sort(5);
	for (int i = 0; i < 5; i++) {
		cout << vectorI[i] << "			";
		cout << vectorD[i] << "         ";
		cout << vectorS[i] << endl;
	}
}