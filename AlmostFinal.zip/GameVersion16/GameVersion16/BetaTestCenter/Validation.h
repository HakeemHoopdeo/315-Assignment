#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include<vector>

using namespace std;

class Validation {
public:
	bool needHelp = false;
	vector<string> usernames;
	Validation();
	~Validation();
	bool isValidInt(string input);
	bool isAskingForHelp(string num);
	bool isPlayerAnsValid(string input);
	bool isUniqueUsername(string name);
	bool validatePlayAgain(string input);
	bool inCategoryRange(string num, int category);
};