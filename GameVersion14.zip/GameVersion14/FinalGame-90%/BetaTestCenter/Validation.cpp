#include "Validation.h"
Validation::Validation() {}
Validation::~Validation() {}

bool Validation::isValidInt(string input) {
	int numDigits = 0;
	const char digits[10] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
	for (int i = 0; i < input.length(); i++) {
		for (int j = 0; j < 10; j++) {
			if (input.at(i) == digits[j])
				numDigits++;
		}
		if (numDigits != 1) 
			return false;
		numDigits = 0;
	}
	return true;
}

bool Validation::isPlayerAnsValid(string input) {
	needHelp = isAskingForHelp(input);
	if ((input.length() == 1 || input.length() == 4) && (input == "T" || input == "F" || input == "t" || input == "f" || needHelp))
		return true;
	return false;
}

bool Validation::isAskingForHelp(string num) {
	string checker = num;
	for (register int i = 0; i < num.length(); i++) 
		checker[i] = tolower(num[i]);
	if (checker == "help") 
		return true;
	return false;
}

bool Validation::isUniqueUsername(string name) {
	if (!usernames.empty()) {
		for (int i = 0; i < usernames.size(); i++) {
			if (usernames[i].compare(name) == 0)
				return false;
		}
	}
	usernames.push_back(name);
	return true;
}

bool Validation::validatePlayAgain(string input) {
	if (input.length() == 1 && input == "x")
		return false;
	return true;
}

bool Validation::inCategoryRange(string input, int category) {
	switch (category) {
	case 0:  //0: numPlayerInRange
		if (stoi(input) < 1 || stoi(input) > 4)
			return false;
		return true;
	case 1:  //1: difficultyLevelInRange
		if (stoi(input) < 0 || stoi(input) > 2)
			return false;
		return true;
	case 2:  //2: numQuestionsInRange
		if (stoi(input) < 5 || stoi(input) > 10)
			return false;
		return true;  
	case 3:  //3: username
		if (input.length() < 3 && input.length() > 20)
			return false;
		return true;	
	default:
		return false;
	}
}