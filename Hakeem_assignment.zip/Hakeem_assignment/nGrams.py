from nltk.util import ngrams
from nltk.lm.preprocessing import pad_both_ends
from nltk.tokenize import word_tokenize
from nltk.lm.preprocessing import padded_everygram_pipeline
from nltk.lm import MLE
from nltk.tokenize import sent_tokenize

userText = input("Enter a string: ")
nGramNumber = int(input("ngram value: "))

mySentences = sent_tokenize(userText)

# Using Sir's fix:
myDoc = []

for sent in mySentences:
    words = []
    myWordSentences = word_tokenize(sent)
    for word in myWordSentences:
        words.append(word)
    myDoc.append(words)
# Sir's fix


myTokenizedText = word_tokenize(userText)
nGrams = list(ngrams(pad_both_ends(myTokenizedText, nGramNumber), nGramNumber))  # padding the word list before hand, ultimately padding it again later on.

neededGramIndex = nGramNumber - 2

myMatrix = [[0 for i in range(neededGramIndex + 1)] for j in range(len(nGrams))]
for i in range(len(nGrams)):
    for j in range(neededGramIndex + 1):
        myMatrix[i][j] = nGrams[i][j]

print("\n" + str(nGramNumber) + "-grams:")
for gram in nGrams:
    print(gram)

myPaddedSentences = [list(pad_both_ends(myTokenizedText, nGramNumber))]

print("\nTraining vocabulary contents: ")
print(myPaddedSentences)

train, vocab = padded_everygram_pipeline(nGramNumber, myDoc)  # The problem, I sent in an already padded text as an argument. Thank you for pointing that out Sir
lm = MLE(nGramNumber)
lm.fit(train, vocab)

numberOfElements = len(nGrams)

columns = ""
rows = ""

print("\n\nMatrix of Probabilities: \n")

for i in range(numberOfElements):  # columns
    columns += str(nGrams[i][neededGramIndex + 1]) + "\t\t"
print(columns + "\n")

for i in range(numberOfElements):  # rows
    for j in range(numberOfElements):
        rows += ("{:.2f}".format(lm.score(nGrams[j][neededGramIndex + 1], myMatrix[
            i])) + "\t\t")  # Over here i have rounded the probabilities to 2 decimal places for NEATNESS, You can undo the formatting to get raw values.
        # for unformatted probabilities, try: str(lm.score(grams[j][neededGramIndex+1],givenMatrix[i]))+"\t\t"
    rows += str(myMatrix[i])
    print(rows)
    rows = ""