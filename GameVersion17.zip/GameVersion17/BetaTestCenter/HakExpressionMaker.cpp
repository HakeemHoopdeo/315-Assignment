// Authors :
// Hakeem Hoopdeo
// Nikiel Ramawthar 
#include "HakExpressionMaker.h"

HakExpressionMaker::HakExpressionMaker() {
	srand((unsigned)time(0));
	this->difficultyLevel = 0;
	this->finalResult = 0;
	genRange();
}

HakExpressionMaker::HakExpressionMaker(int difficulty) {
	srand((unsigned)time(0));
	this->finalResult = 0;
	setDifficultyLevel(difficulty);
}

HakExpressionMaker::~HakExpressionMaker() {}

int HakExpressionMaker::getDifficultyLevel() {
	return this->difficultyLevel;
}

void HakExpressionMaker::setDifficultyLevel(int difficultyLevel) {
	this->difficultyLevel = difficultyLevel;
	genRange();
}

int HakExpressionMaker::getFinalResult() {
	return finalResult;
}

int HakExpressionMaker::getTimeLimit() {
	return timeLimit;
}

string HakExpressionMaker::getExpression() {
	return expression;
}

void HakExpressionMaker::genRange() {
	switch (difficultyLevel) {
	case 0:
		this->lowBound = 2;
		this->upBound = 9;
		this->expLength = 2;
		this->timeLimit = 10;
		break;
	case 1:
		this->lowBound = 10;
		this->upBound = 20;
		this->expLength = 4;
		this->timeLimit = 20;
		break;
	case 2:
		this->lowBound = 20;
		this->upBound = 50;
		this->expLength = 6;
		this->timeLimit = 15;
		break;
	default:
		break;
	}
}

void HakExpressionMaker::genDivisors() {
	divisors.clear();
	divisors.push_back(1);
	if (randNum > 1) {
		for (int i = 2; i <= randNum / 2; i++) {
			if (randNum % i == 0)
				divisors.push_back(i);
		}
	}
	divisors.push_back(randNum);
}

int HakExpressionMaker::genRandNumForDiv() {
	genDivisors();
	if (randNum != 1) {
		if (divisors.size() == 3)
			randNum = divisors.at(1);
		if (divisors.size() > 3) {
			int r = 0;
			while (r == 0)
				r = rand() % (divisors.size() - 2);
			r++;
			randNum = divisors.at(r);
		}
	}
	return randNum;
}

void HakExpressionMaker::genRandOp() {
	int numfactors = 1;
	if (archive != 0)
		randNum = archive;
	for (int j = 2; j < randNum / 2; j++) {
		if (randNum % j == 0) {
			numfactors++;
			break;
		}
	}
	if (numfactors != 1 && !isPrevOpMult) // if it isnt prime and the previous thing wasnt multiplication do what you want
		randOp = rand() % 4;
	else if (numfactors != 1 && isPrevOpMult) {
		randOp = rand() % 4;
		while (randOp == 2)
			randOp = rand() % 4;
	}
	else if (numfactors == 1 && !isPrevOpMult)
		randOp = rand() % 3;
	else
		randOp = rand() % 2;
	if (randOp == 2)
		isPrevOpMult = true;
	else
		isPrevOpMult = false;
	if (randOp != 3) {
		archive = 0;
		isPrevOpDiv = false;
	}
}

void HakExpressionMaker::workingOut(vector<string>& v) {
	workingString += "= ";
	for (auto const& i : v) {
		if (i != " ")
			workingString += i + " ";
	}
	workingString += "\n";
}

string HakExpressionMaker::getSolution() {
	return workingString;
}

int HakExpressionMaker::calculateFinalResult(vector<string>& expVector) {
	int resultantValue = 0;
	for (unsigned int precedence = 3; precedence >= 2; precedence--) {
		for (unsigned int c = 0; c < expVector.size(); c++) {
			if ((expVector[c]).compare(opChoice[precedence]) == 0) {
				int  i = c - 1;
				while (expVector[i] == " ") 
					i--;
				int j = c + 1;
				while (expVector[j] == " ") 
					j++;
				int num1 = std::stoi(expVector[i]);// number before the operator
				int num2 = std::stoi(expVector[j]);// number after the operator
				expVector[c] = to_string((doOperation(precedence, num1, num2)));
				expVector[i] = " ";
				expVector[j] = " ";
				workingOut(expVector);
			}
		}
	}

	for (unsigned int c = 0; c < expVector.size(); c++) {
		if ((expVector[c].compare("+") == 0) || (expVector[c].compare("-") == 0)) {// compares to see if the character is a + or  - symbol
			int  i = c - 1;
			while (expVector[i] == " ")  //this while loop gets the position of the number before the operator
				i--;
			int j = c + 1;
			while (expVector[j] == " ")  //this while loop gets the position of the number before the operator
				j++;
			int num1 = std::stoi(expVector[i]);// number before the operator
			int num2 = std::stoi(expVector[j]);// number after the operator
			int operate = 0;// variable for later use
			if (expVector[c].compare("+") == 0) 
				operate = 1;
			else if (expVector[c].compare("-") == 0) 
				operate = 0;
			expVector[c] = to_string((doOperation(operate, num1, num2)));
			expVector[i] = " ";
			expVector[j] = " ";
			workingOut(expVector);
		}
	}
	unsigned register int k = 0;
	while (k < expVector.size()) {  //while loop to get the resultant value as at this point there should only be 1 value in the vector
		if (expVector[k] != " ") {
			resultantValue = std::stoi(expVector[k]);
			break;
		}
		k++;
	}
	expVector.clear();
	return resultantValue;
}

void HakExpressionMaker::generateExpression() {
	resetAttributes();
	int ranum = 0;
	register int c = 0; //counter used to change from generating a randNum to randOp and vice versa
	for (int i = 0; i < (expLength * 2) - 1; i++) {
		if (i % 2 == 0) {
			if (opChoice[randOp] == "/" && !isPrevOpDiv) {
				archive = ranum;
				ranum = genRandNumForDiv();
				archive = archive / ranum;
				isPrevOpDiv = true;
			}
			else if (opChoice[randOp] == "/" && isPrevOpDiv) {
				randNum = archive;
				ranum = genRandNumForDiv();
				archive = archive / ranum;
			}
			else 
				ranum = genRandNum();
			mathExp.push_back(to_string(ranum));
			expression += to_string(ranum) + " ";

		}//end if
		else {
			genRandOp();
			expression += opChoice[randOp] + " ";
			mathExp.push_back(opChoice[randOp]);

		}
	}
	std::cout << "The Expression is: " << expression << endl;
	divisors.clear();
	finalResult = calculateFinalResult(mathExp);
}