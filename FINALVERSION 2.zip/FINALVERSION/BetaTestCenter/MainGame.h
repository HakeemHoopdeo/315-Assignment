#pragma once
#include <iostream>
#include <map>
#include <queue>
#include<windows.h>
#include <ctime>
#include <cstring>
#include "Validation.h"
#include "HakExpressionMaker.h"
#include "GenericSorting.h"
#include <chrono>  //used for sleeping / waiting
#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <cstdlib>
//in sleeper function 1000 = 1 second. It takes in argument as miliseconds

using namespace std::chrono;
using namespace std;

struct Player {
	int playerNo = 0;
	string username = "";
	int totalScore = 0;
	int totalTime = 0;
	int numQuestionsCorrectlyAnswered = 0;
	map<int, string> Review;  //map that stores the question number and the output for it.
	friend Player operator+(Player const&, Player const&);
};

struct Team {
	string teamName = "";
	Player combinedPlayerStats;
};

class MainGame {
public:
	string difficultyLevel{ 0 };
	string tofVar{ 0 };
	string numPlayer{ 0 };
	string user{ 0 };
	int avatarPos{ 0 };
	vector<string> misfitAvatars = { " (> ^ o^) >"," V.v.V", " (^ OuO^)", " <( ^O^)>" };
	vector<string> misfitNames = { "MUSHY","CRABBY", "JOE","TWEETY" };
	string misfitChoice { 0 }; //1,2,3,4 
	string numQuestions{ 0 };  //used to store the number of questions that the want to have in game
	string playerAnswer{ 0 };  //used to store the players answer - "T" or "F"
	int incorrectAnswer{ 0 };  //used to store a random incorrect answer to the expression
	int correctAnswer{ 0 };  //used to store the correct answer to the expression
	string questionTypeToAsk{ 0 };  //used to store true or false type - randomly generated
	int answerTypeToAsk{ 0 };  //used to store the correct or incorrect answer - randomly generated
	bool playAgain = false;
	queue<Player> playerQueue;
	vector<Player> vecPlayers;
	vector<string> vecUsername;
	vector<int> vecTotalScore;
	vector<int> vecTotalTime;
	vector<int> vecNumQuestionsCorrectlyAnswered;
	Validation valid;
	HakExpressionMaker ExpMaker;
	Player currentPlayer;

	/*Used to create two teams.*/
	void createTeams();

	/*Used in tandem with createTeams() to display the two teams values.*/
	void displayTeams(Team alpha, Team omega);

	/*creates generic class and sorts each vector accordingly.*/
	void sortVectors();

	/*Asks the player(s) a question.*/
	void playerPrompt(int i);

	/*Used to create vectors for the different attributes of each player*/
	void populateVectors();

	/*Used to filter players score into acending order*/
	void filterScore();

	/*Used to filter player Time from fastest to */
	void filterTime();

	void filterCorrectQuestions();

	void filters();

	/*Used to Display a review of the players questions.*/
	void displayReview();
	
	/*Prompts the player to enter the number of players.*/
	void numPlayersPrompt();

	/*Prompts the player to enter the difficulty level.*/
	void difficultyLevelPrompt();

	/*Prompts the player to enter the number of questions.*/
	void numQuestionsPrompt();

	void characterPrompt();

	/*Prompts the player to enter the username.*/
	void usernamePrompt();

	/*Prompts the player to confirm if they are ready to start.*/
	void confirmReadyPrompt();

	/*Prompts the player to play again or end the game.*/
	bool playAgainPrompt();

	/*Generates a random incorrect answer to the expression.*/
	int generateIncorrectAnswer();

	/*Asks question and gets the players answer. */
	void askQuestion(int i);

	/*This will display a bar depicting the progess of the quiz and Mushy.*/
	void questionAccumulator(int i);

	/*Displays each players stats.*/
	void displayStats();

	/*Checks if the answer is correct.*/
	bool isCorrect();

	/*if you take the right answer, it still depends on the randomly generated T or F questionType
	ie. if (A && B), else if (A && !B), else if (!A && B), else if (!A && !B).*/
	void saveAnswer(int i);

	MainGame();
	~MainGame();

	/*Allows a user to input x to go back to the previous question if they typed something incorrectly.*/
	inline bool rollback(string input) {
		if (input == "x" || input == "X") {
			return true;
		}
		return false;
	}

	/*Generates "correct" or "incorrect" type of question*/
	inline string generateQuestionType() {
		if (rand() % 2 == 0)
			return "incorrect";
		return "correct";
	}

	/*if 0, take the wrong answer, else, take the right one*/
	inline int generateRandomlyChosenAnswer() {
		return rand() % 2;
	}

	/*Sleeps based on the difficultyLevel*/
	inline void sleepBasedOnDifficultyLevel() {
		if (ExpMaker.getDifficultyLevel() == 2)
			Sleep(1000);
		else if (ExpMaker.getDifficultyLevel() == 1)
			Sleep(3000);
		else if (ExpMaker.getDifficultyLevel() == 0)
			Sleep(2000);
	}

	/*About the authors.*/
	inline void displayCredits() {
		cout << "\nRETRO-MATH was both designed and developed by 2 Developers:\n" << endl;
		cout << "Hakeem Hoopdeo, 20.\nCurrently in his final year studying towards a degree in Computer Science (Double Major).\nHe is the heart and soul behind this project as well as the main developer for the game.\n";
		cout << "A Quote He lives by: \"Be the best, not the best you think you can be.\"\n\n" << endl;
		cout << "Nikiel Ramawthar, 20.\nAlso in his final year studying towards a degree in Computer Science(Double Major).\nHe is the secondary developer for the game\n";
		cout << "A Quote He lives by: \"Life is a game... Play it.\"\n\n";
	}

	/*Acts as our Player Struct constructor.*/
	inline Player createPlayers(int i) {
		Player p;
		p.playerNo = i;
		p.username = user;
		p.totalScore = 0;
		p.totalTime = 0;
		p.numQuestionsCorrectlyAnswered = 0;
		return p;
	}

	/*Used to calculate a grade symbol based on the score.*/
	inline string getGrade(int score) {
		if (score < (stoi(numQuestions) * 50))
			return "F";
		else if (score >= (stoi(numQuestions) * 50) && score < (stoi(numQuestions) * 60))
			return "D";
		else if (score >= (stoi(numQuestions) * 60) && score < (stoi(numQuestions) * 70))
			return "C";
		else if (score >= (stoi(numQuestions) * 70) && score < (stoi(numQuestions) * 80))
			return "B";
		else
			return "A";
	}

	/*Saves our tag for our output purposes.*/
	inline string getTag(string var) {
		if (var == "true")
			return "correct";
		return "incorrect";
	}
};