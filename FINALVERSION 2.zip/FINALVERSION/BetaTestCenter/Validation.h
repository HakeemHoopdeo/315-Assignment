#pragma once
#include <iostream>
#include <cstring>
#include <string>
#include<vector>

using namespace std;

class Validation {
public:
	vector<string> usernames;
	bool needHelp = false;
	Validation();
	~Validation();
	bool isValidInt(string &input);
	bool isPlayerAnsValid(string &input);
	bool isAskingForHelp(string &num);
	bool isUniqueUsername(string &name);
	bool validatePlayAgain(string &input);
	bool inCategoryRange(string &num, int category);
};
