﻿#include "MainGame.h"



int MainGame::generateIncorrectAnswer() {
	incorrectAnswer = correctAnswer;
	while (incorrectAnswer == correctAnswer)
		incorrectAnswer = (correctAnswer - 10) + (rand() % ((correctAnswer + 10) - (correctAnswer - 10) + 1));
	return incorrectAnswer;
}

void MainGame::singlePlayerPrompt(int i) {
	/* Need Changes */
	currentPlayer = playerQueue.front();
	playerQueue.pop();
	auto start = high_resolution_clock::now();
	string rev = "";
	ExpMaker.generateExpression();
	string Question = ExpMaker.getExpression();
	correctAnswer = ExpMaker.getFinalResult();

	incorrectAnswer = generateIncorrectAnswer();
	int ans = 0;
	if (generateRandomlyChosenAnswer() == 1) {
		answerTypeToAsk = correctAnswer;
	}
	else {
		answerTypeToAsk = incorrectAnswer;
	}
	questionTypeToAsk = generateQuestionType();  // Generates T or F 
	askQuestion(i);
	rev += "The expresssion is : " + Question + "\nIs the result " + to_string(answerTypeToAsk)
		+ " " + questionTypeToAsk + "?";
	if (valid.needHelp) {
		cout << ExpMaker.getSolution();
		cout << "\nEnter any key to continue the quiz!!!";
		string cont = "";
		cin >> cont;
		rev += "\nYou did not answer!!! \nHere's how it's done:\n" + ExpMaker.getSolution();
	}
	else {
		rev += "\nYour Answer was " + toupper(playerAnswer[0]);
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<seconds>(stop - start);
		saveAnswer(i);
		if (isCorrect()) {
			//Display sqrt sign as tick
			//ExpMaker.allSolutions = getWorkingOut();
			currentPlayer.numQuestionsCorrectlyAnswered++;  //increments so we know the total number of incorrect questions
			int value = 10;
			if (duration.count() >= ExpMaker.getTimeLimit()) {
				rev += "\nCORRECT ANSWER... BUT TIME LIMIT EXCEEDED!!! :( ";
			}
			else {
				value += static_cast<int>(std::round((((float)ExpMaker.getTimeLimit() -
					(float)duration.count()) / (float)ExpMaker.getTimeLimit()) * 90));
				rev += " which is " +tofVar+" because the result of the expression is: " + to_string(correctAnswer);
			}
			static_cast<int>(std::round(value));
			currentPlayer.totalScore += value; //Total score
			currentPlayer.totalTime += static_cast<int>(std::round(duration.count())); //Total time taken

			rev += "\nYour Score for this Question was: " + to_string(value) + "\n";
		}
		else {
			//Bad "X"
			rev += " which is "+tofVar+" because the result of the expression is: " + to_string(correctAnswer);
			rev += "\nYour Score for this Question was: 0";
			rev += "\nHere's how it's done:\n" + ExpMaker.getSolution();
		}
		rev += "Time taken was: " + to_string(duration.count()) + " seconds\n";
	}
	ExpMaker.setSolution(i - 1);
	
	rev += "The correct answer was: " + tofVar;
	currentPlayer.Review[i] = { rev };

	playerQueue.push(currentPlayer);


}

void MainGame::displayReview(/*int playerNo*/ ) {

	/* Need changes*/
	cout << "\nSummary of P" << "1 - " << currentPlayer.username << "'s performance: ";
	for (int i = 1; i <= stoi(numQuestions); i++) {
		cout << "\nQuestion" << i << ": " << currentPlayer.Review[i] << "\n";
		Sleep(5000);//sleep for 10 seconds before displaying next reiew
	}
	cout << "\nFor P" << currentPlayer.playerNo << currentPlayer.username << ": ";
	if (currentPlayer.numQuestionsCorrectlyAnswered != 0) {
		cout << "\nThe total number of questions correctly answered is: "
			<< currentPlayer.numQuestionsCorrectlyAnswered << endl;
		cout << "\nThe total time taken to answer the questions is: "
			<< currentPlayer.totalTime << " seconds!" << endl;
	}
	else
		cout << "YOU'VE ANSWERED ALL WRONG!!! MUSHY DIED!!!";
}

void MainGame::saveAnswer(int i /* , int currentPlayerNum */) {
	if ((playerAnswer == "T" || playerAnswer == "t") && !isCorrect()) 
		tofVar = "false";
	else if ((playerAnswer == "F" || playerAnswer == "f") && !isCorrect()) 
		tofVar = "true";
	else if ((playerAnswer == "T" || playerAnswer == "t") && isCorrect()) 
		tofVar = "true";
	else if ((playerAnswer == "F" || playerAnswer == "f") && isCorrect()) 
		tofVar = "false";
}

void MainGame::askQuestion(int i) {
	cout << "Question " << i << " of " << numQuestions << ": ";
	questionAccumulator(i);
	cout << "Is the result " << answerTypeToAsk << " " << questionTypeToAsk /*qType*/  << "?" << endl;
	cin >> playerAnswer;
	while (!valid.isPlayerAnsValid(playerAnswer)) {
		cout << "Invalid format!\nPlease enter a \"T\" or \"F\" or \"HELP\": ";
		cin >> playerAnswer;
	}
}

void MainGame::questionAccumulator(int i) {
	cout << "|";
	for (int j = 1; j <= i; j++) {
		if (j == i) {
			cout << " (>^o^)> |";
		}
		else  //so what if we had the arrow head span 3 lines and the arrow tail 3 lines but in the head have the playerNo so if it's P# turn then 3 is in the arrow head
			/*But we need to work on formatting to leave 2 lines between each players progress bar but it also makes it competitive we can do single and mult as different classesbutBUTBUT We can also compress the code to do it all in the one class :)Which will hurt the brain anBUT :( MusHY likes friends :3fgbedbgdbjegdbbndnjdbjj

			5 tracks for 5 players likea  road basically then if a player gets the answer wrong, they don't advance by one sementb  '*/
			cout << " >>>>-----------1> |";
	}
	int incompletePortion = stoi(numQuestions) - i;
	for (int j = 1; j <= incompletePortion; j++) {
		cout << "     |";
	}
	if (i == stoi(numQuestions))
		cout << "\nALMOST COMPLETE!!! KEEP GOING!!!\n";
	else
		cout << "	MUSHY ZONE\n";
}

bool MainGame::isCorrect() {  //Maybe use a truth table to double check
	if ((answerTypeToAsk == correctAnswer && questionTypeToAsk == "correct" && (playerAnswer == "T" || playerAnswer == "t")) ||
		(answerTypeToAsk == correctAnswer && questionTypeToAsk == "incorrect" && (playerAnswer == "F" || playerAnswer == "f")) ||
		(answerTypeToAsk == incorrectAnswer && questionTypeToAsk == "correct" && (playerAnswer == "F" || playerAnswer == "f")) ||
		(answerTypeToAsk == incorrectAnswer && questionTypeToAsk == "incorrect" && (playerAnswer == "T" || playerAnswer == "t")))
		return true;
	return false;
}

void MainGame::displayStats(MainGame mainGame) {
	mainGame.currentPlayer = mainGame.playerQueue.front();
	mainGame.playerQueue.pop();
	std::system("cls");
	cout << "QUIZ COMPLETE!!! WELL DONE!!! GENERATING RESULTS....";
	Sleep(2000);// sleeps for 5 seconds 
	cout << "\nYour score was: ";
	Sleep(2000);
	cout << mainGame.currentPlayer.totalScore << endl;
	Sleep(2000);
	cout << "Your Grade was: ";
	Sleep(2000);// sleep for 5 seconds before displaying grade
	cout << mainGame.getGrade(mainGame.currentPlayer.totalScore) << endl;
	Sleep(2000);
	cout << "Was Mushy saved?\n";
	Sleep(2000);
	if (mainGame.currentPlayer.totalScore <= (stoi(mainGame.numQuestions) * 50)) {
		cout << "MUSHY COULD NOT BE SAVED!!! x_x \n" << endl;
	}
	else
		cout << "MUSHY WAS SAVED!!! (>^o^)> \n" << endl;
	Sleep(2500);
	mainGame.displayReview();

}

MainGame::MainGame() { }

MainGame::~MainGame() { }

/*MainGame::Player::Player(int pNo, string user, int tScore, int tTime, int numQCorrAns, map<int, string> rev)
{
}
*/
int main() {
	MainGame mainGame;
	srand((unsigned)time(0));
	cout << "Good evening!!!\nGet Mushy (>^o^)> to safety from the fiery arrows";
	mainGame.numPlayersPrompt();
	cout << "GAME STARTING...";


	for (int i = 1; i <= stoi(mainGame.numPlayer) ; i++) {
		mainGame.usernamePrompt();
		mainGame.playerQueue.push(mainGame.createPlayers(i));
	}

	for (int i = 1; i <= stoi(mainGame.numPlayer); i++) {
		//mainGame.playerQueue.push(mainGame.createPlayers(1));
		//should be loop j from 1-numPlayers
		mainGame.currentPlayer = mainGame.playerQueue.front();
		mainGame.playerQueue.pop();

		for (int i = 1; i <= stoi(mainGame.numQuestions); i++) {
			cout << "\nGenerating Question...";
			mainGame.sleepBasedOnDifficultyLevel();
			std::system("cls");
			mainGame.singlePlayerPrompt(i);
		}
		mainGame.playerQueue.push(mainGame.currentPlayer);
		mainGame.displayStats(mainGame);
	}


	/*if (mainGame.numPlayer == "1") {
		mainGame.playerQueue.push(mainGame.createPlayers(1));
		;//should be loop j from 1-numPlayers
		for (int i = 1; i <= stoi(mainGame.numQuestions); i++) {
			cout << "\nGenerating Question...";
			mainGame.sleepBasedOnDifficultyLevel();
			std::system("cls");
			mainGame.singlePlayerPrompt(i);
		}
		mainGame.displayStats(mainGame);
	}
	else {
		//multiPlayerPrompt();
	}*/
	
	//at the end
	cout << "THANK YOU FOR PLAYING OUR GAME!!!";
	mainGame.displayCredits();
}
/*

	AT THE END WHEN WE FINISH PROGRAM - ALL METHODS MUST HAVE REFERENCES TO THE STUFF


	*/