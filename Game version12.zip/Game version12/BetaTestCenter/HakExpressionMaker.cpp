// Authors :
// Hakeem Hoopdeo
// Nikiel Ramawthar 
#include "HakExpressionMaker.h"


//Idrk constructors, pointers, references, friends, etc in C++ properly yet.
//AT THE END
//CLEAN UP WITH POINTERS, DELETING POINTERS, REFERENCES, DELETING ARRAYS,
//DELETING OBJECTS

HakExpressionMaker::HakExpressionMaker() {
	srand((unsigned)time(0));
	this->difficultyLevel = 0;
	this->finalResult = 0;
	genRange();
}

HakExpressionMaker::HakExpressionMaker(int difficulty) {
	srand((unsigned)time(0));
	this->finalResult = 0;
	setDifficultyLevel(difficulty);
}

HakExpressionMaker::~HakExpressionMaker() {}

int HakExpressionMaker::getDifficultyLevel() {
	return this->difficultyLevel;
}

void HakExpressionMaker::setDifficultyLevel(int difficultyLevel) { 
	this->difficultyLevel = difficultyLevel;
	genRange();
}

int HakExpressionMaker::getFinalResult() {
	return finalResult;
}

int HakExpressionMaker::getTimeLimit() {
	return timeLimit;
}

string HakExpressionMaker::getExpression() {
	return expression;
}

void HakExpressionMaker::genRange() {
	switch (difficultyLevel) {
	case 0:
		this->lowBound = 2;
		this->upBound = 9;
		this->expLength = 2;
		this->timeLimit = 10;
		break;
	case 1:
		this->lowBound = 10;
		this->upBound = 20;
		this->expLength = 4;
		this->timeLimit = 20;
		break;
	case 2:
		this->lowBound = 20;
		this->upBound = 50;
		this->expLength = 6;
		this->timeLimit = 15;
		break;
	default:
		break;
	}
}

void HakExpressionMaker::genDivisors() {
	divisors.clear();
	divisors.push_back(1);
	if (randNum > 1) {
		for (int i = 2; i <= randNum / 2; i++) {
			if (randNum % i == 0) 
				divisors.push_back(i);
		}
	}
	divisors.push_back(randNum);
	//When called we must use a pointer and see how to save space
}

int HakExpressionMaker::genRandNumForDiv() {
	genDivisors();
	if (randNum != 1) {
		if (divisors.size() == 3)
			randNum = divisors.at(1);
		if (divisors.size() > 3) {
			int r = 0;
			while (r == 0)
				r = rand() % (divisors.size() - 2);
			r++;
			randNum = divisors.at(r);
		}
	}
	return randNum;
}

void HakExpressionMaker::genRandOp() {
	int numfactors = 1;
	if (archive != 0)  
		randNum = archive; 
	for (int j = 2; j < randNum / 2; j++) {
		if (randNum % j == 0) {
			numfactors++;
			break;
		}
	}//end second for loop
	if (numfactors != 1 && !isPrevOpMult) // if it isnt prime and the previous thing wasnt multiplication do what you want
		randOp = rand() % 4;
	else if (numfactors != 1 && isPrevOpMult) {
		randOp = rand() % 4;
		while (randOp == 2) 
			randOp = rand() % 4;
	}
	else if (numfactors == 1 && !isPrevOpMult) 
		randOp = rand() % 3;
	else 
		randOp = rand() % 2;
	if (randOp == 2) 
		isPrevOpMult = true;
	else 
		isPrevOpMult = false;
	if (randOp != 3) {
		archive = 0;
		isPrevOpDiv = false;
	}
}

void HakExpressionMaker::workingOut(vector<string>& v) {
	workingString += "= ";
	for (auto const& i : v) {
		if (i != " ")
			workingString += i + " ";
	}
	workingString += "\n";
}

string HakExpressionMaker::getSolution() {
	return workingString;
}

void HakExpressionMaker::setSolution(int i) {
	//allSolutions.push_back(workingString);
}

int HakExpressionMaker::calculateFinalResult(vector<string>& expVector) {
	int resultantValue = 0;
	for (unsigned int precedence = 3; precedence >= 2; precedence--) {
		for (unsigned int c = 0; c < expVector.size(); c++) {
			if ((expVector[c]).compare(opChoice[precedence]) == 0) {
				int  i = c - 1;
				while (expVector[i] == " ") {
					i--;
				}
				int j = c + 1;
				while (expVector[j] == " ") {
					j++;
				}

				string previousNumber = expVector[i];
				string forwardNumber = expVector[j];
				int num1 = std::stoi(previousNumber);// number before the operator
				int num2 = std::stoi(forwardNumber);// number after the operator
				expVector[c] = to_string((doOperation(precedence, num1, num2)));
				expVector[i] = " ";
				expVector[j] = " ";
				workingOut(expVector);
			}
		}
	}
	/*
	first we iterate through the vector and doing only division and multiplication
	*/


	for (unsigned int c = 0; c < expVector.size(); c++) {
		if ((expVector[c].compare("+") == 0) || (expVector[c].compare("-") == 0)) {// compares to see if the character is a + or  - symbol
			int  i = c - 1;
			while (expVector[i] == " ") {
				i--;
			}
			/*
				this while loop gets the position of the number before the operator
			*/
			int j = c + 1;
			while (expVector[j] == " ") {
				j++;
			}

			/*
				this while loop gets the position of the number before the operator
			*/
			string previousNumber = expVector[i];
			string forwardNumber = expVector[j];
			int num1 = std::stoi(previousNumber);// number before the operator
			int num2 = std::stoi(forwardNumber);// number after the operator
			int operate = 0;// variable for later use
			if (expVector[c].compare("+") == 0) {
				operate = 1;
			}
			else if (expVector[c].compare("-") == 0) {
				operate = 0;
			}

			/*
				we convert the previous and foward number  to type int
				while at the same time checking what type of operator it is

				i have defined a method DoOperation which takes in the position of the operator in the OpChoice array and two numbers as parameters
				and according to what position it is it carrys out the required equation
				eg if it send 0 it know to carry our division between two numbers and so on


			*/

			expVector[c] = to_string((doOperation(operate, num1, num2)));
			expVector[i] = " ";
			expVector[j] = " ";
			workingOut(expVector);
		}
	}


	/*
		now we iterate through the vector doing normal math addition and subtraction
		because it is only addition and subtraction it does not matter which comes first


		the reason why i created two different loops for the divison and multiplication
		as well as a loop for addition and subtraction is
		addition and subtraction does not worry about order
		eg 2+4-6-8
		it doesnt matter if you do addition or subtraction first althought the sign before the integer matters

		sticking with that number we could do 2+4  = 6
		then 6-6 =0
		then 0 - 8 = 0

		but lets say we have the equation 4-6+10-30
		if we do addition first its not 6+10 = 16
		the 4-16 = -12
		at this point the original program would read it at 12-30 and not -12-30
		it is due to that error i decided to split two for loops
		one to cater for division and multipliaction //will get to why division and multiplication seperate is also important
		and one to cater for addition and subtraction


		now why division and multipolication first?

		well 5+3*6/2


		saying we just read left to right so
		5+3 = 8
		8*6 = 48
		and 48/2 = 24

		now if we do division first 6/2 = 3

		then multiplication
		3*3 = 9
		 and then normal arithmetic operation
		 9+5 = 14
		 theres an offset of 10 in this case that is why the division and multiplication loop preceeds
		 the addition and subtraction loop

	*/
	unsigned int k = 0;

	while (k < expVector.size()) {
		if (expVector[k] != " ") {
			resultantValue = std::stoi(expVector[k]);
			break;
		}
		k++;
	}

	/*
		while loop to get the resultant value as at this point there should only be 1 value in the vector
	*/
	expVector.clear();
	return resultantValue;
}

void HakExpressionMaker::generateExpression() {
	resetAttributes();
	int ranum = 0;
	register int c = 0; //counter used to change from generating a randNum to randOp and vice versa
	for (int i = 0; i < (expLength * 2) - 1; i++) {

		if (i % 2 == 0) {
			if (opChoice[randOp] == "/" && !isPrevOpDiv) {
				archive = ranum;
				ranum = genRandNumForDiv();
				archive = archive / ranum;
				isPrevOpDiv = true;
			}
			else if (opChoice[randOp] == "/" && isPrevOpDiv) {
				randNum = archive;
				ranum = genRandNumForDiv();
				archive = archive / ranum;
			}
			else {
				ranum = genRandNum();
			}
			mathExp.push_back(to_string(ranum));
			expression += to_string(ranum) + " ";

		}//end if
		else {
			genRandOp();
			expression += opChoice[randOp] + " ";
			mathExp.push_back(opChoice[randOp]);

		}//end big else
	}// end forloop
	std::cout << "The Expression is: " << expression << endl;
	divisors.clear();
	finalResult = calculateFinalResult(mathExp);
}

/*int main() {
	srand((unsigned) time(0));
	cout << "Easy = 0 " << endl;
	cout << "Challenging = 1 " << endl;
	cout << "God Mode = 2 " << endl;
	cout << "Enter difficulty Level : ";

	int diff;
	cin >> diff;

	while (diff > 2) {
		cout << "Invalid difficulty, Enter Difficulty : ";
		cin >> diff;
	}
	for (int i = 0; i < 15; i++) {
		HakExpressionMaker myExpMaker(diff);
		myExpMaker.generateExpression();
		//cout << myExpMaker.getFinalResult();
		cout << "\n\n";
	}
	return 0;
}*/