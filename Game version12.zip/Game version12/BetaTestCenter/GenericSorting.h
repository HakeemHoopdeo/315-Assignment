#pragma once
#include <iostream>
#include <string>
#include <vector>

using namespace std;

/* IF WE USE A QUEUE OF TYPE PLAYER INSTEAD OF A MAP TO STORE EACH PLAYER, LETS JUST 
MAKE THE TEMPLATE FUNCTION WORK FOR VECTORS AND NOT ARRAYS SO THAT WE HAVE ENOUGH USE OF 
VECTORS AND DON'T FORGET TO CHANGE THE VECTOR ALLOCATOR IN THE TEMPLATE FUNCTION <T, A>*/

template<typename T/*, typename A*/> class GenericSorting {
private:
	//T* items;
	//std::vector<T, A> const& items;
	vector<T/*, A*/>* items;
public:
	bool compareTo(T val1, T val2);
	void sort(int n);
	//GenericSorting(/*T *items*/);
	GenericSorting(vector<T>* items);
	~GenericSorting();
	
};

template<typename T> bool GenericSorting<T>::compareTo(T val1, T val2) {
	if (val1 < val2)
		return true;  //Team A attribute val1 is < Team B attribute val2 or could do OO Overloading
	else
		return false;
}


template<typename T/*, typename A*/> void GenericSorting<T/*, A*/>::sort(int n) {
	T currentMax;
	int currentMaxIndex;

	for (int i = n - 1; i >= 1; i--) {
		//Finds the maximum in the items [0..1]
		currentMax = items->at(i);
		currentMaxIndex = i;

		for (int j = i - 1; j >= 0; j--) {
			if (/*currentMax < items->at(j)*/compareTo(currentMax, items->at(j))) {
				currentMax = items->at(j);
				currentMaxIndex = j;
			}
		}

		//swap items[i] with items[currentMaxIndex] if necessary
		if (currentMaxIndex != i) {
			items->at(currentMaxIndex) = items->at(i);
			items->at(i) = currentMax;
		}
	}
}

/*template<typename T/*, typename A*//*> GenericSorting<T/*, A*//*>::GenericSorting(/*T* items*//*) {
	this->items = items;
}*/

template<typename T> GenericSorting<T>::GenericSorting(vector<T>* items) {
	//for (unsigned int i = 0; i < items->size; i++) {
		//this->items->at(i) = items->at(i);
	//}
	this->items = items;
}

template<typename T/*, typename A*/> GenericSorting<T/*, A*/>::~GenericSorting() {

}//
/*2v2
Teamwork
End - operator overloadingg, to get the total number of questions correct from team A
get the total time taken by team A
get the total score from team A

Team A: 2P
Team B: 2P
Pl's turn for Team A
P3's turn for Team B
P2's turn for Team A
P4's turn for Team B
score: float
numQuestionsCorrect: int
Time: int
Score: float

//We would've used Operator Overloading to add two add two Player structs for both teams
//We'll have




Sorting function which is used to see which player is the best at a certain category
MVP: numQuestionsCorrect, score, time
MVP - the single person who performed the best of all of them
*/
