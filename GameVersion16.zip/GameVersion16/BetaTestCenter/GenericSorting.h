#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "MainGame.h"

using namespace std;

template<typename T, typename E> class GenericSorting {
private:
	vector<T>* items;
	vector<E>* vp;
	bool compareTo(T val1, T val2);
public:
	void sort(int n);
	GenericSorting(vector<T>* items, vector<E>* vp);
	~GenericSorting();
	//Make a copy constructor for the vector<E> vp
};

template<typename T, typename E> bool GenericSorting<T,E>::compareTo(T val1, T val2) {
	if (val1 < val2)
		return true; 
	else
		return false;
}

template<typename T, typename E> void GenericSorting<T,E>::sort(int n) {
	T currentMax; E playerTracker;
	int currentMaxIndex;

	for (int i = n - 1; i >= 1; i--) {
		//Finds the maximum in the items [0..1]
		currentMax = items->at(i);
		playerTracker = vp->at(i);
		currentMaxIndex = i;

		for (int j = i - 1; j >= 0; j--) {
			if (compareTo(currentMax, items->at(j))) {
				currentMax = items->at(j);
				playerTracker = vp->at(j);
				currentMaxIndex = j;
			}
		}

		//int j = i - 1;


		//swap items[i] with items[currentMaxIndex] if necessary
		if (currentMaxIndex != i) {
			items->at(currentMaxIndex) = items->at(i);
			items->at(i) = currentMax;
			vp->at(currentMaxIndex) = vp->at(i);
			vp->at(i) = playerTracker;
		}
	}
}

template<typename T, typename E> GenericSorting<T,E>::GenericSorting(vector<T>* items, vector<E>* vp) {
	this->items = items;
	this->vp = vp;
}

template<typename T, typename E> GenericSorting<T,E>::~GenericSorting() {

}